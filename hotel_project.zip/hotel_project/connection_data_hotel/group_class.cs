﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace connection_data_hotel
{
     class connection_setting
    {
        public static string connection = "server=.;database=hotel_DB;user id=sa;password=sa123456";
    }

    public class employyees_and_role_tabel
    {
        public static int find_employee(string name , string id)
        {

            int result = 0;
            string query = @"
                SELECT role_id
                FROM roles 
                WHERE (SELECT employees.role_id 
                FROM employees 
                WHERE employee_id = @id 
                AND employee_name = @name) = @id ";

            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", name);

                try
                {
                    conn.Open();
                    object queryResult = cmd.ExecuteScalar();
                    result = Convert.ToInt32(queryResult);
                }
                catch (Exception ex)
                {
                    // Log the exception (ex) if needed
                    result = 0;
                }
            }

            return result;

        }

        public static DataTable get_employee(int id)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT roles.*, employees.*
                FROM employees INNER JOIN
                roles ON employees.role_id = roles.role_id
                where employees.employee_id = @id";

            using(SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using(SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id",id);
                    conn.Open();
                    try
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                            dt.Load(reader);
                    }
                    catch
                    {
                        dt = null;
                    }
                }
            }
            return dt;
        }

    }

    public class room_tabel
    {
        public static DataTable select_free_room (string type_room)
        {
            DataTable room_data = new DataTable();

            string query = @"SELECT top 2 rooms.room_id,tariffs.coast, services_type.service_name FROM     rooms INNER JOIN
                  tariffs ON rooms.tarif_id = tariffs.tariff_id INNER JOIN
                  services_type ON tariffs.service_type_id = services_type.service_type_id
				  where rooms.room_state = 0 and services_type.service_name = @type_room
				  order by rooms.free_up_room";
            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue (@"type_room", type_room);
                    try
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                            room_data.Load(reader);
                        else
                            room_data = null;
                    }
                    catch (Exception ex)
                    {
                        room_data = null;
                    }
                }
            }
            return room_data;
        }

        public static int count_rows_free(int tarif_id)
        {
            int result = 0;
            string query = @"
                select count(1) from rooms
                    where tarif_id = @tarif_id and room_state = 0";

            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@tarif_id", tarif_id);

                try
                {
                    conn.Open();
                    object queryResult = cmd.ExecuteScalar();
                    result = Convert.ToInt32(queryResult);
                }
                catch (Exception ex)
                {
                    // Log the exception (ex) if needed
                    result = 0;
                }
            }

            return result;
        }

        public static DataTable select_reservation_room()
        {
            DataTable room_data = new DataTable();

            string query = "select room_id from rooms where room_state = 1";
            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                            room_data.Load(reader);
                        else
                            room_data = null;
                    }
                    catch (Exception ex)
                    {
                        room_data = null;
                    }
                }
            }
            return room_data;
        }

    }

    public class parking_tabel
    {
        public static DataTable select_free_parking(string type_parking)
        {
            DataTable parking_data = new DataTable();

            string query = @"SELECT top 2 parking.parking_id, services_type.service_name, tariffs.coast
            FROM parking INNER JOIN
			tariffs ON parking.tarif_id = tariffs.tariff_id INNER JOIN
			services_type ON tariffs.service_type_id = services_type.service_type_id
			where services_type.service_name = @type_parking 
			and parking.parking_state = 0
			order by parking.change_parking_state";
            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue(@"type_parking", type_parking);
                    try
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                            parking_data.Load(reader);
                        else
                            parking_data = null;
                    }
                    catch (Exception ex)
                    {
                        parking_data = null;
                    }
                }
            }
            return parking_data;
        }

        public static int count_parking_free(int tarif_id)
        {
            int result = 0;
            string query = @"
             select count(1) from parking
             where tarif_id = tarif_id and parking_state = 0";

            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@tarif_id", tarif_id);

                try
                {
                    conn.Open();
                    object queryResult = cmd.ExecuteScalar();
                    result = Convert.ToInt32(queryResult);
                }
                catch (Exception ex)
                {
                    // Log the exception (ex) if needed
                    result = 0;
                }
            }

            return result;
        }
    }

    public class customar_tabel
    {
        public static int add_customar(string name , DateTime birthdate , string nationalaty , bool gender
            , int pasport_number , DateTime end_pasport)
        {
            int id_customar = 0;
            string query = @"INSERT INTO [dbo].[cutomars]
           ([customar_name],[birthdate],[nationality]
           ,[gender],[passport_number],[passport_end_date])
        VALUES
            (@name,@birthdate,@nationalaty,@gender
           ,@pasport_number,@end_pasport
		   )
            select SCOPE_IDENTITY() AS NewCustomerID
            ";

            using(SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using(SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@birthdate", birthdate);
                    cmd.Parameters.AddWithValue("@nationalaty", nationalaty);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@pasport_number", pasport_number);
                    cmd.Parameters.AddWithValue("@end_pasport", end_pasport);
                    conn.Open();
                    try
                    {
                        object value = cmd.ExecuteScalar();                       
                        if (value != null)
                            id_customar = Convert.ToInt32(value);
                    }
                    catch
                    {
                        id_customar = 0;
                    }
                    return id_customar;
                }
            }
        }
    }

    public class reservation_tabel
    {
         public static bool add_reservation(int customer_id, int room_id , int parking_id, DateTime reservation_date 
           , DateTime reservation_end_date , int reservation_cost ,int service_total_cost 
             ,DateTime reservation_parking_date, DateTime reservation_parkink_end_date )
        {
            bool flage = false;
            string query = @"INSERT INTO [reservations]
           (reservation_id
           ,customer_id
           ,room_id
           ,parking_id
           ,reservation_date
           ,reservation_end_date
           ,reservation_coast
           ,service_total_coast)
     VALUES
           ( @reservation_id,
             @customer_id, 
		     @room_id ,
		     @parking_id, 
		     @reservation_date ,
             @reservation_end_date ,
		     @reservation_cost ,
		     @service_total_cost)

     update rooms
        set room_state = 1 where room_id = @room_id

    if @parking_id > 0 
    begin 
	    update parking
	        set parking_state = 1 where parking_id = @parking_id;
        update reservations
            set reservation_parking_date = GETDATE()  ,
                reservation_parkink_end_date = GETDATE() where reservation_id = @reservation_id ;     
    end

";

            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@reservation_id", customer_id+room_id);
                    cmd.Parameters.AddWithValue("@customer_id", customer_id);
                    cmd.Parameters.AddWithValue("@room_id", room_id);
                    cmd.Parameters.AddWithValue("@parking_id", parking_id);
                    cmd.Parameters.AddWithValue("@reservation_date", reservation_date);
                    cmd.Parameters.AddWithValue("@reservation_end_date", reservation_end_date);
                    cmd.Parameters.AddWithValue("@reservation_cost", reservation_cost);
                    cmd.Parameters.AddWithValue("@service_total_cost", service_total_cost);
                    
                    conn.Open();
                    try
                    {
                        int row_effect = cmd.ExecuteNonQuery();
                        if (row_effect > 0)
                            flage = true;
                    }
                    catch
                    {
                        flage = false;
                    }
                    return flage;
                }
            }
        }

        public static DataTable get_reservation_not_end(int id_room)
        {
            DataTable room_data = new DataTable();

            string query = @"SELECT 
                reservations.reservation_id,  
                reservations.customer_id,  
                cutomars.customar_name,  
                cutomars.passport_number,  
                reservations.room_id,  
                services_type.service_name, 
                reservations.parking_id, 
                CASE 
                    WHEN reservations.parking_id != 0 THEN parking_services.service_name  
                    ELSE ' '  
                END AS parking_service_name, 
                reservations.reservation_date, 
                reservations.reservation_end_date, 
                reservations.reservation_coast, 
                reservations.service_total_coast, 
                reservations.reservation_parking_date,  
                reservations.reservation_parkink_end_date 
            FROM  
                cutomars  
                INNER JOIN reservations ON cutomars.customar_id = reservations.customer_id  
                INNER JOIN parking ON reservations.parking_id = parking.parking_id 
                INNER JOIN rooms ON reservations.room_id = rooms.room_id  
                LEFT JOIN tariffs parking_tariffs ON parking.tarif_id = parking_tariffs.tariff_id 
                LEFT JOIN services_type parking_services ON parking_tariffs.service_type_id = parking_services.service_type_id
                LEFT JOIN tariffs room_tariffs ON rooms.tarif_id = room_tariffs.tariff_id
                LEFT JOIN services_type ON room_tariffs.service_type_id = services_type.service_type_id
            WHERE  
                rooms.room_state = 1  
                AND reservations.end_reservation IS NULL
            	and  reservations.room_id = @id_room
            ";
            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id_room", id_room);
                    try
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                            room_data.Load(reader);
                        else
                            room_data = null;
                    }
                    catch (Exception ex)
                    {
                        room_data = null;
                    }
                }
            }
            return room_data;
        }

        public static bool end_reservation(int reservation_id , int room_id , int parking_id)
        {
            bool flage = false;
            string query = "begin transaction " +
                "begin try " +
                    "update reservations " +
                    "set end_reservation = 0 where reservation_id = @reservation_id " +
                    "update rooms " +
                    "set room_state = 0  where room_id = @room_id " +
                    "if (select parking_id  from reservations where reservation_id = @reservation_id) != 0 " +
                    "begin " +
                        "update parking " +
                        "set parking_state = 0   where parking_id = @parking_id " +
                    "end " +
                    "commit " +
                 "end try " +
                 "begin catch  " +
                    "rollback; " +
                 "end catch";

            using (SqlConnection conn = new SqlConnection(connection_setting.connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@reservation_id", reservation_id);
                    cmd.Parameters.AddWithValue("@room_id", room_id);
                    cmd.Parameters.AddWithValue("@parking_id", parking_id);

                    conn.Open();
                    try
                    {
                        int row_effect = cmd.ExecuteNonQuery();
                        if (row_effect > 0)
                            flage = true;
                    }
                    catch
                    {
                        flage = false;
                    }
                    return flage;
                }
            }
        }

    }

}
