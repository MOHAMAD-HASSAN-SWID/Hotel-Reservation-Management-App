﻿namespace hotel_project
{
    partial class Form_Select_room
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Select_room));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.kryptonButton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonPanel7 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_room_suite_number = new System.Windows.Forms.Label();
            this.label_room_double_number = new System.Windows.Forms.Label();
            this.label_room_singel_number = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.kryptonPanel6 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_6 = new System.Windows.Forms.Label();
            this.label_room_type_6 = new System.Windows.Forms.Label();
            this.label_room_number_6 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.kryptonPanel5 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_5 = new System.Windows.Forms.Label();
            this.label_room_type_5 = new System.Windows.Forms.Label();
            this.label_room_number_5 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.kryptonPanel4 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_3 = new System.Windows.Forms.Label();
            this.label_room_type_3 = new System.Windows.Forms.Label();
            this.label_room_number_3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.kryptonPanel2 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_1 = new System.Windows.Forms.Label();
            this.label_room_type_1 = new System.Windows.Forms.Label();
            this.label_room_number_1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.kryptonPanel1 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_2 = new System.Windows.Forms.Label();
            this.label_room_type_2 = new System.Windows.Forms.Label();
            this.label_room_number_2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.kryptonPanel3 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_cost_4 = new System.Windows.Forms.Label();
            this.label_room_type_4 = new System.Windows.Forms.Label();
            this.label_room_number_4 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).BeginInit();
            this.kryptonPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel6)).BeginInit();
            this.kryptonPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel5)).BeginInit();
            this.kryptonPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).BeginInit();
            this.kryptonPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel2)).BeginInit();
            this.kryptonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).BeginInit();
            this.kryptonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel3)).BeginInit();
            this.kryptonPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.groupBox1.Controls.Add(this.kryptonButton1);
            this.groupBox1.Controls.Add(this.kryptonPanel7);
            this.groupBox1.Controls.Add(this.kryptonPanel6);
            this.groupBox1.Controls.Add(this.kryptonPanel5);
            this.groupBox1.Controls.Add(this.kryptonPanel4);
            this.groupBox1.Controls.Add(this.kryptonPanel2);
            this.groupBox1.Controls.Add(this.kryptonPanel1);
            this.groupBox1.Controls.Add(this.kryptonPanel3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1063, 447);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Room";
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Cursor = System.Windows.Forms.Cursors.PanEast;
            this.kryptonButton1.Location = new System.Drawing.Point(877, 383);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.OverrideDefault.Back.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonButton1.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonButton1.OverrideDefault.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.OverrideDefault.Border.Rounding = 20;
            this.kryptonButton1.OverrideFocus.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonButton1.OverrideFocus.Back.Color2 = System.Drawing.Color.MistyRose;
            this.kryptonButton1.OverrideFocus.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.OverrideFocus.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.OverrideFocus.Border.Rounding = 20;
            this.kryptonButton1.Size = new System.Drawing.Size(146, 46);
            this.kryptonButton1.StateCommon.Back.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonButton1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonButton1.StateCommon.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StateCommon.Border.Rounding = 20;
            this.kryptonButton1.StateNormal.Back.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonButton1.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonButton1.StateNormal.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StateNormal.Border.Rounding = 20;
            this.kryptonButton1.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonButton1.StatePressed.Back.Color2 = System.Drawing.Color.MistyRose;
            this.kryptonButton1.StatePressed.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounding3;
            this.kryptonButton1.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StatePressed.Border.Rounding = 20;
            this.kryptonButton1.TabIndex = 18;
            this.kryptonButton1.Values.Text = "Check Out";
            this.kryptonButton1.Click += new System.EventHandler(this.kryptonButton1_Click);
            // 
            // kryptonPanel7
            // 
            this.kryptonPanel7.Controls.Add(this.label_room_suite_number);
            this.kryptonPanel7.Controls.Add(this.label_room_double_number);
            this.kryptonPanel7.Controls.Add(this.label_room_singel_number);
            this.kryptonPanel7.Controls.Add(this.label41);
            this.kryptonPanel7.Controls.Add(this.label42);
            this.kryptonPanel7.Controls.Add(this.label43);
            this.kryptonPanel7.Location = new System.Drawing.Point(12, 333);
            this.kryptonPanel7.Name = "kryptonPanel7";
            this.kryptonPanel7.Size = new System.Drawing.Size(1011, 44);
            this.kryptonPanel7.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel7.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel7.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel7.TabIndex = 17;
            // 
            // label_room_suite_number
            // 
            this.label_room_suite_number.AutoSize = true;
            this.label_room_suite_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_suite_number.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_suite_number.ForeColor = System.Drawing.Color.Black;
            this.label_room_suite_number.Location = new System.Drawing.Point(874, 10);
            this.label_room_suite_number.Name = "label_room_suite_number";
            this.label_room_suite_number.Size = new System.Drawing.Size(32, 24);
            this.label_room_suite_number.TabIndex = 11;
            this.label_room_suite_number.Text = "20";
            // 
            // label_room_double_number
            // 
            this.label_room_double_number.AutoSize = true;
            this.label_room_double_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_double_number.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_double_number.ForeColor = System.Drawing.Color.Black;
            this.label_room_double_number.Location = new System.Drawing.Point(529, 10);
            this.label_room_double_number.Name = "label_room_double_number";
            this.label_room_double_number.Size = new System.Drawing.Size(32, 24);
            this.label_room_double_number.TabIndex = 10;
            this.label_room_double_number.Text = "10";
            // 
            // label_room_singel_number
            // 
            this.label_room_singel_number.AutoSize = true;
            this.label_room_singel_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_singel_number.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_singel_number.ForeColor = System.Drawing.Color.Black;
            this.label_room_singel_number.Location = new System.Drawing.Point(184, 10);
            this.label_room_singel_number.Name = "label_room_singel_number";
            this.label_room_singel_number.Size = new System.Drawing.Size(21, 24);
            this.label_room_singel_number.TabIndex = 9;
            this.label_room_singel_number.Text = "5";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label41.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(686, 10);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(127, 24);
            this.label41.TabIndex = 8;
            this.label41.Text = "#Room Suite";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label42.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(341, 10);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(134, 24);
            this.label42.TabIndex = 7;
            this.label42.Text = "#Rom Double";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label43.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(15, 10);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(134, 24);
            this.label43.TabIndex = 6;
            this.label43.Text = "#Room singel";
            // 
            // kryptonPanel6
            // 
            this.kryptonPanel6.Controls.Add(this.label_cost_6);
            this.kryptonPanel6.Controls.Add(this.label_room_type_6);
            this.kryptonPanel6.Controls.Add(this.label_room_number_6);
            this.kryptonPanel6.Controls.Add(this.label34);
            this.kryptonPanel6.Controls.Add(this.label35);
            this.kryptonPanel6.Controls.Add(this.label36);
            this.kryptonPanel6.Controls.Add(this.button6);
            this.kryptonPanel6.Location = new System.Drawing.Point(702, 187);
            this.kryptonPanel6.Name = "kryptonPanel6";
            this.kryptonPanel6.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel6.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel6.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel6.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel6.TabIndex = 15;
            // 
            // label_cost_6
            // 
            this.label_cost_6.AutoSize = true;
            this.label_cost_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_6.ForeColor = System.Drawing.Color.Black;
            this.label_cost_6.Location = new System.Drawing.Point(158, 95);
            this.label_cost_6.Name = "label_cost_6";
            this.label_cost_6.Size = new System.Drawing.Size(42, 24);
            this.label_cost_6.TabIndex = 11;
            this.label_cost_6.Text = "null";
            // 
            // label_room_type_6
            // 
            this.label_room_type_6.AutoSize = true;
            this.label_room_type_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_6.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_6.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_6.Name = "label_room_type_6";
            this.label_room_type_6.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_6.TabIndex = 10;
            this.label_room_type_6.Text = "null";
            // 
            // label_room_number_6
            // 
            this.label_room_number_6.AutoSize = true;
            this.label_room_number_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_6.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_6.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_6.Name = "label_room_number_6";
            this.label_room_number_6.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_6.TabIndex = 9;
            this.label_room_number_6.Text = "null";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label34.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(15, 95);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(106, 24);
            this.label34.TabIndex = 8;
            this.label34.Text = "Room Cost";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label35.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(15, 56);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(111, 24);
            this.label35.TabIndex = 7;
            this.label35.Text = "Room Type";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label36.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(15, 19);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(137, 24);
            this.label36.TabIndex = 6;
            this.label36.Text = "Room Number";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(321, 140);
            this.button6.TabIndex = 12;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // kryptonPanel5
            // 
            this.kryptonPanel5.Controls.Add(this.label_cost_5);
            this.kryptonPanel5.Controls.Add(this.label_room_type_5);
            this.kryptonPanel5.Controls.Add(this.label_room_number_5);
            this.kryptonPanel5.Controls.Add(this.label28);
            this.kryptonPanel5.Controls.Add(this.label29);
            this.kryptonPanel5.Controls.Add(this.label30);
            this.kryptonPanel5.Controls.Add(this.button5);
            this.kryptonPanel5.Location = new System.Drawing.Point(702, 41);
            this.kryptonPanel5.Name = "kryptonPanel5";
            this.kryptonPanel5.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel5.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel5.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel5.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel5.TabIndex = 14;
            // 
            // label_cost_5
            // 
            this.label_cost_5.AutoSize = true;
            this.label_cost_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_5.ForeColor = System.Drawing.Color.Black;
            this.label_cost_5.Location = new System.Drawing.Point(158, 95);
            this.label_cost_5.Name = "label_cost_5";
            this.label_cost_5.Size = new System.Drawing.Size(42, 24);
            this.label_cost_5.TabIndex = 11;
            this.label_cost_5.Text = "null";
            // 
            // label_room_type_5
            // 
            this.label_room_type_5.AutoSize = true;
            this.label_room_type_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_5.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_5.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_5.Name = "label_room_type_5";
            this.label_room_type_5.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_5.TabIndex = 10;
            this.label_room_type_5.Text = "null";
            // 
            // label_room_number_5
            // 
            this.label_room_number_5.AutoSize = true;
            this.label_room_number_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_5.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_5.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_5.Name = "label_room_number_5";
            this.label_room_number_5.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_5.TabIndex = 9;
            this.label_room_number_5.Text = "null";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label28.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(15, 95);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(106, 24);
            this.label28.TabIndex = 8;
            this.label28.Text = "Room Cost";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label29.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(15, 56);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 24);
            this.label29.TabIndex = 7;
            this.label29.Text = "Room Type";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label30.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(15, 19);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(137, 24);
            this.label30.TabIndex = 6;
            this.label30.Text = "Room Number";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Location = new System.Drawing.Point(0, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(321, 140);
            this.button5.TabIndex = 12;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // kryptonPanel4
            // 
            this.kryptonPanel4.Controls.Add(this.label_cost_3);
            this.kryptonPanel4.Controls.Add(this.label_room_type_3);
            this.kryptonPanel4.Controls.Add(this.label_room_number_3);
            this.kryptonPanel4.Controls.Add(this.label22);
            this.kryptonPanel4.Controls.Add(this.label23);
            this.kryptonPanel4.Controls.Add(this.label24);
            this.kryptonPanel4.Controls.Add(this.button4);
            this.kryptonPanel4.Location = new System.Drawing.Point(357, 41);
            this.kryptonPanel4.Name = "kryptonPanel4";
            this.kryptonPanel4.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel4.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel4.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel4.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel4.TabIndex = 13;
            // 
            // label_cost_3
            // 
            this.label_cost_3.AutoSize = true;
            this.label_cost_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_3.ForeColor = System.Drawing.Color.Black;
            this.label_cost_3.Location = new System.Drawing.Point(158, 95);
            this.label_cost_3.Name = "label_cost_3";
            this.label_cost_3.Size = new System.Drawing.Size(42, 24);
            this.label_cost_3.TabIndex = 11;
            this.label_cost_3.Text = "null";
            // 
            // label_room_type_3
            // 
            this.label_room_type_3.AutoSize = true;
            this.label_room_type_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_3.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_3.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_3.Name = "label_room_type_3";
            this.label_room_type_3.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_3.TabIndex = 10;
            this.label_room_type_3.Text = "null";
            // 
            // label_room_number_3
            // 
            this.label_room_number_3.AutoSize = true;
            this.label_room_number_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_3.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_3.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_3.Name = "label_room_number_3";
            this.label_room_number_3.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_3.TabIndex = 9;
            this.label_room_number_3.Text = "null";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label22.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(15, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(106, 24);
            this.label22.TabIndex = 8;
            this.label22.Text = "Room Cost";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label23.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(15, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(111, 24);
            this.label23.TabIndex = 7;
            this.label23.Text = "Room Type";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label24.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(15, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(137, 24);
            this.label24.TabIndex = 6;
            this.label24.Text = "Room Number";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(321, 140);
            this.button4.TabIndex = 12;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // kryptonPanel2
            // 
            this.kryptonPanel2.Controls.Add(this.label_cost_1);
            this.kryptonPanel2.Controls.Add(this.label_room_type_1);
            this.kryptonPanel2.Controls.Add(this.label_room_number_1);
            this.kryptonPanel2.Controls.Add(this.label10);
            this.kryptonPanel2.Controls.Add(this.label11);
            this.kryptonPanel2.Controls.Add(this.label12);
            this.kryptonPanel2.Controls.Add(this.button3);
            this.kryptonPanel2.Location = new System.Drawing.Point(12, 41);
            this.kryptonPanel2.Name = "kryptonPanel2";
            this.kryptonPanel2.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel2.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel2.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel2.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel2.TabIndex = 13;
            // 
            // label_cost_1
            // 
            this.label_cost_1.AutoSize = true;
            this.label_cost_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_1.ForeColor = System.Drawing.Color.Black;
            this.label_cost_1.Location = new System.Drawing.Point(158, 95);
            this.label_cost_1.Name = "label_cost_1";
            this.label_cost_1.Size = new System.Drawing.Size(42, 24);
            this.label_cost_1.TabIndex = 11;
            this.label_cost_1.Text = "null";
            // 
            // label_room_type_1
            // 
            this.label_room_type_1.AutoSize = true;
            this.label_room_type_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_1.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_1.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_1.Name = "label_room_type_1";
            this.label_room_type_1.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_1.TabIndex = 10;
            this.label_room_type_1.Text = "null";
            // 
            // label_room_number_1
            // 
            this.label_room_number_1.AutoSize = true;
            this.label_room_number_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_1.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_1.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_1.Name = "label_room_number_1";
            this.label_room_number_1.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_1.TabIndex = 9;
            this.label_room_number_1.Text = "null";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(15, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 24);
            this.label10.TabIndex = 8;
            this.label10.Text = "Room Cost";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 24);
            this.label11.TabIndex = 7;
            this.label11.Text = "Room Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(15, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 24);
            this.label12.TabIndex = 6;
            this.label12.Text = "Room Number";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(321, 140);
            this.button3.TabIndex = 12;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // kryptonPanel1
            // 
            this.kryptonPanel1.Controls.Add(this.label_cost_2);
            this.kryptonPanel1.Controls.Add(this.label_room_type_2);
            this.kryptonPanel1.Controls.Add(this.label_room_number_2);
            this.kryptonPanel1.Controls.Add(this.label4);
            this.kryptonPanel1.Controls.Add(this.label5);
            this.kryptonPanel1.Controls.Add(this.label6);
            this.kryptonPanel1.Controls.Add(this.button2);
            this.kryptonPanel1.Location = new System.Drawing.Point(12, 187);
            this.kryptonPanel1.Name = "kryptonPanel1";
            this.kryptonPanel1.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel1.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel1.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel1.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel1.TabIndex = 13;
            // 
            // label_cost_2
            // 
            this.label_cost_2.AutoSize = true;
            this.label_cost_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_2.ForeColor = System.Drawing.Color.Black;
            this.label_cost_2.Location = new System.Drawing.Point(158, 95);
            this.label_cost_2.Name = "label_cost_2";
            this.label_cost_2.Size = new System.Drawing.Size(42, 24);
            this.label_cost_2.TabIndex = 11;
            this.label_cost_2.Text = "null";
            // 
            // label_room_type_2
            // 
            this.label_room_type_2.AutoSize = true;
            this.label_room_type_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_2.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_2.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_2.Name = "label_room_type_2";
            this.label_room_type_2.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_2.TabIndex = 10;
            this.label_room_type_2.Text = "null";
            // 
            // label_room_number_2
            // 
            this.label_room_number_2.AutoSize = true;
            this.label_room_number_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_2.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_2.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_2.Name = "label_room_number_2";
            this.label_room_number_2.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_2.TabIndex = 9;
            this.label_room_number_2.Text = "null";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(15, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Room Cost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(15, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "Room Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(15, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "Room Number";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(321, 140);
            this.button2.TabIndex = 12;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // kryptonPanel3
            // 
            this.kryptonPanel3.Controls.Add(this.label_cost_4);
            this.kryptonPanel3.Controls.Add(this.label_room_type_4);
            this.kryptonPanel3.Controls.Add(this.label_room_number_4);
            this.kryptonPanel3.Controls.Add(this.label16);
            this.kryptonPanel3.Controls.Add(this.label17);
            this.kryptonPanel3.Controls.Add(this.label18);
            this.kryptonPanel3.Controls.Add(this.button1);
            this.kryptonPanel3.Location = new System.Drawing.Point(357, 187);
            this.kryptonPanel3.Name = "kryptonPanel3";
            this.kryptonPanel3.Size = new System.Drawing.Size(321, 140);
            this.kryptonPanel3.StateCommon.Color1 = System.Drawing.Color.MistyRose;
            this.kryptonPanel3.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.kryptonPanel3.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Dashed;
            this.kryptonPanel3.TabIndex = 12;
            // 
            // label_cost_4
            // 
            this.label_cost_4.AutoSize = true;
            this.label_cost_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_cost_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost_4.ForeColor = System.Drawing.Color.Black;
            this.label_cost_4.Location = new System.Drawing.Point(158, 95);
            this.label_cost_4.Name = "label_cost_4";
            this.label_cost_4.Size = new System.Drawing.Size(42, 24);
            this.label_cost_4.TabIndex = 11;
            this.label_cost_4.Text = "null";
            // 
            // label_room_type_4
            // 
            this.label_room_type_4.AutoSize = true;
            this.label_room_type_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_type_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_type_4.ForeColor = System.Drawing.Color.Black;
            this.label_room_type_4.Location = new System.Drawing.Point(158, 56);
            this.label_room_type_4.Name = "label_room_type_4";
            this.label_room_type_4.Size = new System.Drawing.Size(42, 24);
            this.label_room_type_4.TabIndex = 10;
            this.label_room_type_4.Text = "null";
            // 
            // label_room_number_4
            // 
            this.label_room_number_4.AutoSize = true;
            this.label_room_number_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_room_number_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_room_number_4.ForeColor = System.Drawing.Color.Black;
            this.label_room_number_4.Location = new System.Drawing.Point(158, 19);
            this.label_room_number_4.Name = "label_room_number_4";
            this.label_room_number_4.Size = new System.Drawing.Size(42, 24);
            this.label_room_number_4.TabIndex = 9;
            this.label_room_number_4.Text = "null";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(15, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 24);
            this.label16.TabIndex = 8;
            this.label16.Text = "Room Cost";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(15, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 24);
            this.label17.TabIndex = 7;
            this.label17.Text = "Room Type";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(15, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(137, 24);
            this.label18.TabIndex = 6;
            this.label18.Text = "Room Number";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(321, 140);
            this.button1.TabIndex = 12;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form_Select_room
            // 
            this.BackgroundImage = global::hotel_project.Properties.Resources._f748b5b1_0cff_46dd_8bbd_f07e196f3283;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1063, 671);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Select_room";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(169)))));
            this.StateActive.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.StateActive.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Switch50;
            this.StateActive.Header.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(169)))));
            this.StateActive.Header.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.StateActive.Header.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_book_room_FormClosed);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).EndInit();
            this.kryptonPanel7.ResumeLayout(false);
            this.kryptonPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel6)).EndInit();
            this.kryptonPanel6.ResumeLayout(false);
            this.kryptonPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel5)).EndInit();
            this.kryptonPanel5.ResumeLayout(false);
            this.kryptonPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).EndInit();
            this.kryptonPanel4.ResumeLayout(false);
            this.kryptonPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel2)).EndInit();
            this.kryptonPanel2.ResumeLayout(false);
            this.kryptonPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).EndInit();
            this.kryptonPanel1.ResumeLayout(false);
            this.kryptonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel3)).EndInit();
            this.kryptonPanel3.ResumeLayout(false);
            this.kryptonPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel3;
        private System.Windows.Forms.Label label_cost_4;
        private System.Windows.Forms.Label label_room_type_4;
        private System.Windows.Forms.Label label_room_number_4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel6;
        private System.Windows.Forms.Label label_cost_6;
        private System.Windows.Forms.Label label_room_type_6;
        private System.Windows.Forms.Label label_room_number_6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button6;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel5;
        private System.Windows.Forms.Label label_cost_5;
        private System.Windows.Forms.Label label_room_type_5;
        private System.Windows.Forms.Label label_room_number_5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button5;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel4;
        private System.Windows.Forms.Label label_cost_3;
        private System.Windows.Forms.Label label_room_type_3;
        private System.Windows.Forms.Label label_room_number_3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button4;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel2;
        private System.Windows.Forms.Label label_cost_1;
        private System.Windows.Forms.Label label_room_type_1;
        private System.Windows.Forms.Label label_room_number_1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button3;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel1;
        private System.Windows.Forms.Label label_cost_2;
        private System.Windows.Forms.Label label_room_type_2;
        private System.Windows.Forms.Label label_room_number_2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button2;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel7;
        private System.Windows.Forms.Label label_room_suite_number;
        private System.Windows.Forms.Label label_room_double_number;
        private System.Windows.Forms.Label label_room_singel_number;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton1;
    }
}