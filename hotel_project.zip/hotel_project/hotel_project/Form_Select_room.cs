﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace hotel_project
{
    public partial class Form_Select_room : KryptonForm
    {
        information_data_hotel.room_tabel.information_room[] info_room = new information_data_hotel.room_tabel.information_room[6];

        public Form_Select_room()
        {
            InitializeComponent();
            _select_free_up_room();

        }

        void open_form_room(information_data_hotel.room_tabel.information_room info_room)
        {
            Form_book_rom form = new Form_book_rom(info_room);
            form.Show();
            this.Close();
        }

        void _full_label()
        {
            if (info_room[0].id_room != 0)
            {
                label_room_number_1.Text = info_room[0].id_room.ToString().ToUpperInvariant();
                label_room_type_1.Text = info_room[0].type_room.ToString().ToUpper();
                label_cost_1.Text = info_room[0].cost_room.ToString() + "$";
            }
            else
            {
                button3.Enabled = false;
            }

            if (info_room[1].id_room != 0)
            {
                label_room_number_2.Text = info_room[1].id_room.ToString();
                label_room_type_2.Text = info_room[1].type_room.ToString().ToUpper();
                label_cost_2.Text = info_room[1].cost_room.ToString() + "$";
            }
            else
            {
                button2.Enabled = false;
            }

            if (info_room[2].id_room != 0)
            {
                label_room_number_3.Text = info_room[2].id_room.ToString();
                label_room_type_3.Text = info_room[2].type_room.ToString().ToUpper();
                label_cost_3.Text = info_room[2].cost_room.ToString() + "$";
            }
            else
            {
                button4.Enabled = false;
            }

            if (info_room[3].id_room != 0)
            {
                label_room_number_4.Text = info_room[3].id_room.ToString();
                label_room_type_4.Text = info_room[3].type_room.ToString().ToUpper();
                label_cost_4.Text = info_room[3].cost_room.ToString() + "$";
            }
            else
            {
                button1.Enabled = false;
            }

            if (info_room[4].id_room != 0)
            {
                label_room_number_5.Text = info_room[4].id_room.ToString();
                label_room_type_5.Text = info_room[4].type_room.ToString().ToUpper();
                label_cost_5.Text = info_room[4].cost_room.ToString() + "$";
            }
            else
            {
                button5.Enabled = false;
            }
            if (info_room[5].id_room != 0)
            {
                label_room_number_6.Text = info_room[5].id_room.ToString();
                label_room_type_6.Text = info_room[5].type_room.ToString().ToUpper();
                label_cost_6.Text = info_room[5].cost_room.ToString() + "$";
            }
            else
            {
                button6.Enabled = false;
            }
        }
        void _select_free_up_room()
        {
            information_data_hotel.room_tabel.select_free_up_room("single room", info_room, 0);
            information_data_hotel.room_tabel.select_free_up_room("double room", info_room, 2);
            information_data_hotel.room_tabel.select_free_up_room("suite room", info_room, 4);
            
            _full_label();

            label_room_singel_number.Text = information_data_hotel.room_tabel.count_free_room(1).ToString();
            label_room_double_number.Text = information_data_hotel.room_tabel.count_free_room(2).ToString();
            label_room_suite_number.Text = information_data_hotel.room_tabel.count_free_room(3).ToString();

        }

        private void Form_book_room_FormClosed(object sender, FormClosedEventArgs e)
        {
            bool flage = false;
            foreach (Form form_open in Application.OpenForms)
            {
                if (!form_open.IsDisposed)
                    flage = true;
            }
            if (!flage)
                Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[0]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[2]);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[4]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[1]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[3]);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            open_form_room(info_room[5]);
        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
            Form_issuing_invoice form = new Form_issuing_invoice();
            form.Show();
            this.Close();
        }
    }
}
