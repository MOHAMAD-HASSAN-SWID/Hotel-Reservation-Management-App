﻿namespace hotel_project
{
    partial class Form_book_rom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_book_rom));
            this.kryptonPanel_passport = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonTextBox_many_day_book_room = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.dateTimePicker_birthdate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_end_passport = new System.Windows.Forms.DateTimePicker();
            this.kryptonTextBox_nationalty = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBox_pasport_number = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBox_name = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.radioButton_femal = new System.Windows.Forms.RadioButton();
            this.radioButton_mal = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_total_cost_parking = new System.Windows.Forms.Label();
            this.kryptonTextBox_many_day_book_parking = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.kryptonPanel7 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_parking_vip = new System.Windows.Forms.Label();
            this.label_parking_normal = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.kryptonPanel4 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_parking_cost_3 = new System.Windows.Forms.Label();
            this.label_parking_type_3 = new System.Windows.Forms.Label();
            this.label_parking_number_3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.kryptonPanel2 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_parking_cost_1 = new System.Windows.Forms.Label();
            this.label_parking_type_1 = new System.Windows.Forms.Label();
            this.label_parking_number_1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.kryptonPanel3 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_parking_cost_2 = new System.Windows.Forms.Label();
            this.label_parking_type_2 = new System.Windows.Forms.Label();
            this.label1_parking_number_2 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.kryptonPanel8 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.label_parking_cost_4 = new System.Windows.Forms.Label();
            this.label_parking_type_4 = new System.Windows.Forms.Label();
            this.label_parking_number_4 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.kryptonButton1 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButton2 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.label25 = new System.Windows.Forms.Label();
            this.label_total_cost = new System.Windows.Forms.Label();
            this.kryptonButton3 = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_passport)).BeginInit();
            this.kryptonPanel_passport.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).BeginInit();
            this.kryptonPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).BeginInit();
            this.kryptonPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel2)).BeginInit();
            this.kryptonPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel3)).BeginInit();
            this.kryptonPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel8)).BeginInit();
            this.kryptonPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPanel_passport
            // 
            this.kryptonPanel_passport.Controls.Add(this.kryptonTextBox_many_day_book_room);
            this.kryptonPanel_passport.Controls.Add(this.label27);
            this.kryptonPanel_passport.Controls.Add(this.dateTimePicker_birthdate);
            this.kryptonPanel_passport.Controls.Add(this.dateTimePicker_end_passport);
            this.kryptonPanel_passport.Controls.Add(this.kryptonTextBox_nationalty);
            this.kryptonPanel_passport.Controls.Add(this.kryptonTextBox_pasport_number);
            this.kryptonPanel_passport.Controls.Add(this.kryptonTextBox_name);
            this.kryptonPanel_passport.Controls.Add(this.label6);
            this.kryptonPanel_passport.Controls.Add(this.radioButton_femal);
            this.kryptonPanel_passport.Controls.Add(this.radioButton_mal);
            this.kryptonPanel_passport.Controls.Add(this.label5);
            this.kryptonPanel_passport.Controls.Add(this.label4);
            this.kryptonPanel_passport.Controls.Add(this.label3);
            this.kryptonPanel_passport.Controls.Add(this.label2);
            this.kryptonPanel_passport.Controls.Add(this.label1);
            this.kryptonPanel_passport.Dock = System.Windows.Forms.DockStyle.Left;
            this.kryptonPanel_passport.Location = new System.Drawing.Point(3, 25);
            this.kryptonPanel_passport.Name = "kryptonPanel_passport";
            this.kryptonPanel_passport.Size = new System.Drawing.Size(928, 238);
            this.kryptonPanel_passport.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel_passport.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel_passport.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel_passport.TabIndex = 0;
            // 
            // kryptonTextBox_many_day_book_room
            // 
            this.kryptonTextBox_many_day_book_room.Location = new System.Drawing.Point(604, 182);
            this.kryptonTextBox_many_day_book_room.Name = "kryptonTextBox_many_day_book_room";
            this.kryptonTextBox_many_day_book_room.Size = new System.Drawing.Size(276, 42);
            this.kryptonTextBox_many_day_book_room.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonTextBox_many_day_book_room.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBox_many_day_book_room.StateActive.Border.Rounding = 15;
            this.kryptonTextBox_many_day_book_room.StateActive.Content.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBox_many_day_book_room.TabIndex = 19;
            this.kryptonTextBox_many_day_book_room.Text = "1";
            this.kryptonTextBox_many_day_book_room.TextChanged += new System.EventHandler(this.kryptonTextBox_many_day_book_room_TextChanged);
            this.kryptonTextBox_many_day_book_room.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kryptonTextBox_many_day_book_room_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label27.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(406, 196);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(192, 24);
            this.label27.TabIndex = 18;
            this.label27.Text = "How many day book";
            // 
            // dateTimePicker_birthdate
            // 
            this.dateTimePicker_birthdate.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.dateTimePicker_birthdate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_birthdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_birthdate.Location = new System.Drawing.Point(126, 91);
            this.dateTimePicker_birthdate.Name = "dateTimePicker_birthdate";
            this.dateTimePicker_birthdate.Size = new System.Drawing.Size(316, 32);
            this.dateTimePicker_birthdate.TabIndex = 17;
            // 
            // dateTimePicker_end_passport
            // 
            this.dateTimePicker_end_passport.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.dateTimePicker_end_passport.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_end_passport.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_end_passport.Location = new System.Drawing.Point(615, 55);
            this.dateTimePicker_end_passport.Name = "dateTimePicker_end_passport";
            this.dateTimePicker_end_passport.Size = new System.Drawing.Size(265, 32);
            this.dateTimePicker_end_passport.TabIndex = 16;
            // 
            // kryptonTextBox_nationalty
            // 
            this.kryptonTextBox_nationalty.Location = new System.Drawing.Point(126, 135);
            this.kryptonTextBox_nationalty.Name = "kryptonTextBox_nationalty";
            this.kryptonTextBox_nationalty.Size = new System.Drawing.Size(316, 42);
            this.kryptonTextBox_nationalty.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonTextBox_nationalty.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBox_nationalty.StateActive.Border.Rounding = 15;
            this.kryptonTextBox_nationalty.StateActive.Content.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBox_nationalty.TabIndex = 15;
            // 
            // kryptonTextBox_pasport_number
            // 
            this.kryptonTextBox_pasport_number.Location = new System.Drawing.Point(604, 102);
            this.kryptonTextBox_pasport_number.Name = "kryptonTextBox_pasport_number";
            this.kryptonTextBox_pasport_number.Size = new System.Drawing.Size(276, 42);
            this.kryptonTextBox_pasport_number.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonTextBox_pasport_number.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBox_pasport_number.StateActive.Border.Rounding = 15;
            this.kryptonTextBox_pasport_number.StateActive.Content.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBox_pasport_number.TabIndex = 14;
            this.kryptonTextBox_pasport_number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kryptonTextBox2_KeyPress);
            // 
            // kryptonTextBox_name
            // 
            this.kryptonTextBox_name.Location = new System.Drawing.Point(126, 29);
            this.kryptonTextBox_name.Name = "kryptonTextBox_name";
            this.kryptonTextBox_name.Size = new System.Drawing.Size(316, 42);
            this.kryptonTextBox_name.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonTextBox_name.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBox_name.StateActive.Border.Rounding = 15;
            this.kryptonTextBox_name.StateActive.Content.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBox_name.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(71, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 24);
            this.label6.TabIndex = 12;
            this.label6.Text = "Gendar";
            // 
            // radioButton_femal
            // 
            this.radioButton_femal.AutoSize = true;
            this.radioButton_femal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.radioButton_femal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_femal.Location = new System.Drawing.Point(289, 196);
            this.radioButton_femal.Name = "radioButton_femal";
            this.radioButton_femal.Size = new System.Drawing.Size(85, 28);
            this.radioButton_femal.TabIndex = 11;
            this.radioButton_femal.TabStop = true;
            this.radioButton_femal.Text = "Femal";
            this.radioButton_femal.UseVisualStyleBackColor = false;
            // 
            // radioButton_mal
            // 
            this.radioButton_mal.AutoSize = true;
            this.radioButton_mal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.radioButton_mal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_mal.Location = new System.Drawing.Point(176, 198);
            this.radioButton_mal.Name = "radioButton_mal";
            this.radioButton_mal.Size = new System.Drawing.Size(62, 28);
            this.radioButton_mal.TabIndex = 10;
            this.radioButton_mal.TabStop = true;
            this.radioButton_mal.Text = "Mal";
            this.radioButton_mal.UseVisualStyleBackColor = false;
            this.radioButton_mal.CheckedChanged += new System.EventHandler(this.radioButton_mal_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(454, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "passport end";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "BirthDate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nationalty";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(493, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "passport";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.kryptonPanel_passport);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1179, 266);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Get Information";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(937, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(239, 238);
            this.panel1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.groupBox2.Controls.Add(this.label_total_cost_parking);
            this.groupBox2.Controls.Add(this.kryptonTextBox_many_day_book_parking);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.kryptonPanel7);
            this.groupBox2.Controls.Add(this.kryptonPanel4);
            this.groupBox2.Controls.Add(this.kryptonPanel2);
            this.groupBox2.Controls.Add(this.kryptonPanel3);
            this.groupBox2.Controls.Add(this.kryptonPanel8);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(0, 344);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1179, 441);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "parking";
            // 
            // label_total_cost_parking
            // 
            this.label_total_cost_parking.AutoSize = true;
            this.label_total_cost_parking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_total_cost_parking.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_total_cost_parking.ForeColor = System.Drawing.Color.Black;
            this.label_total_cost_parking.Location = new System.Drawing.Point(522, 397);
            this.label_total_cost_parking.Name = "label_total_cost_parking";
            this.label_total_cost_parking.Size = new System.Drawing.Size(21, 24);
            this.label_total_cost_parking.TabIndex = 22;
            this.label_total_cost_parking.Text = "0";
            // 
            // kryptonTextBox_many_day_book_parking
            // 
            this.kryptonTextBox_many_day_book_parking.Location = new System.Drawing.Point(223, 383);
            this.kryptonTextBox_many_day_book_parking.Name = "kryptonTextBox_many_day_book_parking";
            this.kryptonTextBox_many_day_book_parking.Size = new System.Drawing.Size(276, 42);
            this.kryptonTextBox_many_day_book_parking.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonTextBox_many_day_book_parking.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonTextBox_many_day_book_parking.StateActive.Border.Rounding = 15;
            this.kryptonTextBox_many_day_book_parking.StateActive.Content.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonTextBox_many_day_book_parking.TabIndex = 21;
            this.kryptonTextBox_many_day_book_parking.Text = "0";
            this.kryptonTextBox_many_day_book_parking.TextChanged += new System.EventHandler(this.kryptonTextBox_many_day_book_parking_TextChanged);
            this.kryptonTextBox_many_day_book_parking.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kryptonTextBox_many_day_book_parking_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label28.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(25, 397);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(192, 24);
            this.label28.TabIndex = 20;
            this.label28.Text = "How many day book";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Location = new System.Drawing.Point(759, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(417, 407);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // kryptonPanel7
            // 
            this.kryptonPanel7.Controls.Add(this.label_parking_vip);
            this.kryptonPanel7.Controls.Add(this.label_parking_normal);
            this.kryptonPanel7.Controls.Add(this.label42);
            this.kryptonPanel7.Controls.Add(this.label43);
            this.kryptonPanel7.Location = new System.Drawing.Point(12, 333);
            this.kryptonPanel7.Name = "kryptonPanel7";
            this.kryptonPanel7.Size = new System.Drawing.Size(741, 44);
            this.kryptonPanel7.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel7.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel7.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel7.TabIndex = 17;
            // 
            // label_parking_vip
            // 
            this.label_parking_vip.AutoSize = true;
            this.label_parking_vip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_vip.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_vip.ForeColor = System.Drawing.Color.Black;
            this.label_parking_vip.Location = new System.Drawing.Point(709, 10);
            this.label_parking_vip.Name = "label_parking_vip";
            this.label_parking_vip.Size = new System.Drawing.Size(32, 24);
            this.label_parking_vip.TabIndex = 10;
            this.label_parking_vip.Text = "10";
            // 
            // label_parking_normal
            // 
            this.label_parking_normal.AutoSize = true;
            this.label_parking_normal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_normal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_normal.ForeColor = System.Drawing.Color.Black;
            this.label_parking_normal.Location = new System.Drawing.Point(314, 10);
            this.label_parking_normal.Name = "label_parking_normal";
            this.label_parking_normal.Size = new System.Drawing.Size(21, 24);
            this.label_parking_normal.TabIndex = 9;
            this.label_parking_normal.Text = "5";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label42.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(392, 10);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(127, 24);
            this.label42.TabIndex = 7;
            this.label42.Text = "#parking VIP";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label43.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(15, 10);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(161, 24);
            this.label43.TabIndex = 6;
            this.label43.Text = "#parking Normal";
            // 
            // kryptonPanel4
            // 
            this.kryptonPanel4.Controls.Add(this.label_parking_cost_3);
            this.kryptonPanel4.Controls.Add(this.label_parking_type_3);
            this.kryptonPanel4.Controls.Add(this.label_parking_number_3);
            this.kryptonPanel4.Controls.Add(this.label22);
            this.kryptonPanel4.Controls.Add(this.label23);
            this.kryptonPanel4.Controls.Add(this.label24);
            this.kryptonPanel4.Controls.Add(this.button4);
            this.kryptonPanel4.Location = new System.Drawing.Point(388, 41);
            this.kryptonPanel4.Name = "kryptonPanel4";
            this.kryptonPanel4.Size = new System.Drawing.Size(365, 140);
            this.kryptonPanel4.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel4.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel4.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel4.TabIndex = 13;
            // 
            // label_parking_cost_3
            // 
            this.label_parking_cost_3.AutoSize = true;
            this.label_parking_cost_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_cost_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_cost_3.ForeColor = System.Drawing.Color.Black;
            this.label_parking_cost_3.Location = new System.Drawing.Point(173, 95);
            this.label_parking_cost_3.Name = "label_parking_cost_3";
            this.label_parking_cost_3.Size = new System.Drawing.Size(54, 24);
            this.label_parking_cost_3.TabIndex = 11;
            this.label_parking_cost_3.Text = "150$";
            // 
            // label_parking_type_3
            // 
            this.label_parking_type_3.AutoSize = true;
            this.label_parking_type_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_type_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_type_3.ForeColor = System.Drawing.Color.Black;
            this.label_parking_type_3.Location = new System.Drawing.Point(173, 56);
            this.label_parking_type_3.Name = "label_parking_type_3";
            this.label_parking_type_3.Size = new System.Drawing.Size(40, 24);
            this.label_parking_type_3.TabIndex = 10;
            this.label_parking_type_3.Text = "VIP";
            // 
            // label_parking_number_3
            // 
            this.label_parking_number_3.AutoSize = true;
            this.label_parking_number_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_number_3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_number_3.ForeColor = System.Drawing.Color.Black;
            this.label_parking_number_3.Location = new System.Drawing.Point(173, 19);
            this.label_parking_number_3.Name = "label_parking_number_3";
            this.label_parking_number_3.Size = new System.Drawing.Size(43, 24);
            this.label_parking_number_3.TabIndex = 9;
            this.label_parking_number_3.Text = "405";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label22.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(15, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(121, 24);
            this.label22.TabIndex = 8;
            this.label22.Text = "Parking Cost";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label23.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(15, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(126, 24);
            this.label23.TabIndex = 7;
            this.label23.Text = "Parking Type";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label24.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(15, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(152, 24);
            this.label24.TabIndex = 6;
            this.label24.Text = "Parking Number";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(365, 140);
            this.button4.TabIndex = 12;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // kryptonPanel2
            // 
            this.kryptonPanel2.Controls.Add(this.label_parking_cost_1);
            this.kryptonPanel2.Controls.Add(this.label_parking_type_1);
            this.kryptonPanel2.Controls.Add(this.label_parking_number_1);
            this.kryptonPanel2.Controls.Add(this.label10);
            this.kryptonPanel2.Controls.Add(this.label11);
            this.kryptonPanel2.Controls.Add(this.label12);
            this.kryptonPanel2.Controls.Add(this.button3);
            this.kryptonPanel2.Location = new System.Drawing.Point(12, 41);
            this.kryptonPanel2.Name = "kryptonPanel2";
            this.kryptonPanel2.Size = new System.Drawing.Size(365, 140);
            this.kryptonPanel2.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel2.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel2.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel2.TabIndex = 13;
            // 
            // label_parking_cost_1
            // 
            this.label_parking_cost_1.AutoSize = true;
            this.label_parking_cost_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_cost_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_cost_1.ForeColor = System.Drawing.Color.Black;
            this.label_parking_cost_1.Location = new System.Drawing.Point(173, 95);
            this.label_parking_cost_1.Name = "label_parking_cost_1";
            this.label_parking_cost_1.Size = new System.Drawing.Size(54, 24);
            this.label_parking_cost_1.TabIndex = 11;
            this.label_parking_cost_1.Text = "100$";
            // 
            // label_parking_type_1
            // 
            this.label_parking_type_1.AutoSize = true;
            this.label_parking_type_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_type_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_type_1.ForeColor = System.Drawing.Color.Black;
            this.label_parking_type_1.Location = new System.Drawing.Point(173, 56);
            this.label_parking_type_1.Name = "label_parking_type_1";
            this.label_parking_type_1.Size = new System.Drawing.Size(74, 24);
            this.label_parking_type_1.TabIndex = 10;
            this.label_parking_type_1.Text = "Normal";
            // 
            // label_parking_number_1
            // 
            this.label_parking_number_1.AutoSize = true;
            this.label_parking_number_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_number_1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_number_1.ForeColor = System.Drawing.Color.Black;
            this.label_parking_number_1.Location = new System.Drawing.Point(173, 19);
            this.label_parking_number_1.Name = "label_parking_number_1";
            this.label_parking_number_1.Size = new System.Drawing.Size(43, 24);
            this.label_parking_number_1.TabIndex = 9;
            this.label_parking_number_1.Text = "405";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(15, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 24);
            this.label10.TabIndex = 8;
            this.label10.Text = "Parking Cost";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 24);
            this.label11.TabIndex = 7;
            this.label11.Text = "Parking Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(15, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 24);
            this.label12.TabIndex = 6;
            this.label12.Text = "Parking Number";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(365, 140);
            this.button3.TabIndex = 12;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // kryptonPanel3
            // 
            this.kryptonPanel3.Controls.Add(this.label_parking_cost_2);
            this.kryptonPanel3.Controls.Add(this.label_parking_type_2);
            this.kryptonPanel3.Controls.Add(this.label1_parking_number_2);
            this.kryptonPanel3.Controls.Add(this.label16);
            this.kryptonPanel3.Controls.Add(this.label17);
            this.kryptonPanel3.Controls.Add(this.label18);
            this.kryptonPanel3.Controls.Add(this.button2);
            this.kryptonPanel3.Location = new System.Drawing.Point(12, 187);
            this.kryptonPanel3.Name = "kryptonPanel3";
            this.kryptonPanel3.Size = new System.Drawing.Size(365, 140);
            this.kryptonPanel3.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel3.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel3.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel3.TabIndex = 13;
            // 
            // label_parking_cost_2
            // 
            this.label_parking_cost_2.AutoSize = true;
            this.label_parking_cost_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_cost_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_cost_2.ForeColor = System.Drawing.Color.Black;
            this.label_parking_cost_2.Location = new System.Drawing.Point(173, 95);
            this.label_parking_cost_2.Name = "label_parking_cost_2";
            this.label_parking_cost_2.Size = new System.Drawing.Size(54, 24);
            this.label_parking_cost_2.TabIndex = 11;
            this.label_parking_cost_2.Text = "100$";
            // 
            // label_parking_type_2
            // 
            this.label_parking_type_2.AutoSize = true;
            this.label_parking_type_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_type_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_type_2.ForeColor = System.Drawing.Color.Black;
            this.label_parking_type_2.Location = new System.Drawing.Point(173, 56);
            this.label_parking_type_2.Name = "label_parking_type_2";
            this.label_parking_type_2.Size = new System.Drawing.Size(74, 24);
            this.label_parking_type_2.TabIndex = 10;
            this.label_parking_type_2.Text = "Normal";
            // 
            // label1_parking_number_2
            // 
            this.label1_parking_number_2.AutoSize = true;
            this.label1_parking_number_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label1_parking_number_2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_parking_number_2.ForeColor = System.Drawing.Color.Black;
            this.label1_parking_number_2.Location = new System.Drawing.Point(173, 19);
            this.label1_parking_number_2.Name = "label1_parking_number_2";
            this.label1_parking_number_2.Size = new System.Drawing.Size(43, 24);
            this.label1_parking_number_2.TabIndex = 9;
            this.label1_parking_number_2.Text = "405";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(15, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 24);
            this.label16.TabIndex = 8;
            this.label16.Text = "Parking Cost";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(15, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(126, 24);
            this.label17.TabIndex = 7;
            this.label17.Text = "Parking Type";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(15, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(152, 24);
            this.label18.TabIndex = 6;
            this.label18.Text = "Parking Number";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(365, 140);
            this.button2.TabIndex = 12;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // kryptonPanel8
            // 
            this.kryptonPanel8.Controls.Add(this.label_parking_cost_4);
            this.kryptonPanel8.Controls.Add(this.label_parking_type_4);
            this.kryptonPanel8.Controls.Add(this.label_parking_number_4);
            this.kryptonPanel8.Controls.Add(this.label46);
            this.kryptonPanel8.Controls.Add(this.label47);
            this.kryptonPanel8.Controls.Add(this.label48);
            this.kryptonPanel8.Controls.Add(this.button1);
            this.kryptonPanel8.Location = new System.Drawing.Point(388, 187);
            this.kryptonPanel8.Name = "kryptonPanel8";
            this.kryptonPanel8.Size = new System.Drawing.Size(365, 140);
            this.kryptonPanel8.StateCommon.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonPanel8.StateCommon.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonPanel8.StateCommon.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonPanel8.TabIndex = 12;
            // 
            // label_parking_cost_4
            // 
            this.label_parking_cost_4.AutoSize = true;
            this.label_parking_cost_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_cost_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_cost_4.ForeColor = System.Drawing.Color.Black;
            this.label_parking_cost_4.Location = new System.Drawing.Point(173, 95);
            this.label_parking_cost_4.Name = "label_parking_cost_4";
            this.label_parking_cost_4.Size = new System.Drawing.Size(54, 24);
            this.label_parking_cost_4.TabIndex = 11;
            this.label_parking_cost_4.Text = "150$";
            // 
            // label_parking_type_4
            // 
            this.label_parking_type_4.AutoSize = true;
            this.label_parking_type_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_type_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_type_4.ForeColor = System.Drawing.Color.Black;
            this.label_parking_type_4.Location = new System.Drawing.Point(173, 56);
            this.label_parking_type_4.Name = "label_parking_type_4";
            this.label_parking_type_4.Size = new System.Drawing.Size(40, 24);
            this.label_parking_type_4.TabIndex = 10;
            this.label_parking_type_4.Text = "VIP";
            // 
            // label_parking_number_4
            // 
            this.label_parking_number_4.AutoSize = true;
            this.label_parking_number_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label_parking_number_4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_parking_number_4.ForeColor = System.Drawing.Color.Black;
            this.label_parking_number_4.Location = new System.Drawing.Point(173, 19);
            this.label_parking_number_4.Name = "label_parking_number_4";
            this.label_parking_number_4.Size = new System.Drawing.Size(43, 24);
            this.label_parking_number_4.TabIndex = 9;
            this.label_parking_number_4.Text = "405";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label46.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(15, 95);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(121, 24);
            this.label46.TabIndex = 8;
            this.label46.Text = "Parking Cost";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label47.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Black;
            this.label47.Location = new System.Drawing.Point(15, 56);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(126, 24);
            this.label47.TabIndex = 7;
            this.label47.Text = "Parking Type";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.label48.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(15, 19);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(152, 24);
            this.label48.TabIndex = 6;
            this.label48.Text = "Parking Number";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(365, 140);
            this.button1.TabIndex = 12;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // kryptonButton1
            // 
            this.kryptonButton1.Location = new System.Drawing.Point(299, 281);
            this.kryptonButton1.Name = "kryptonButton1";
            this.kryptonButton1.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton1.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton1.OverrideDefault.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton1.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.OverrideDefault.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.OverrideDefault.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.OverrideFocus.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton1.OverrideFocus.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton1.OverrideFocus.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.OverrideFocus.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.OverrideFocus.Border.Rounding = 10;
            this.kryptonButton1.OverrideFocus.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.OverrideFocus.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.Size = new System.Drawing.Size(295, 69);
            this.kryptonButton1.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton1.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonButton1.StateCommon.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton1.StateCommon.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton1.StateNormal.Border.Rounding = 10;
            this.kryptonButton1.StateNormal.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton1.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton1.StatePressed.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton1.StatePressed.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton1.TabIndex = 9;
            this.kryptonButton1.Values.Text = "Cash";
            this.kryptonButton1.Click += new System.EventHandler(this.kryptonButton1_Click);
            // 
            // kryptonButton2
            // 
            this.kryptonButton2.Location = new System.Drawing.Point(692, 281);
            this.kryptonButton2.Name = "kryptonButton2";
            this.kryptonButton2.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton2.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton2.OverrideDefault.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton2.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton2.OverrideDefault.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.OverrideFocus.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton2.OverrideFocus.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton2.OverrideFocus.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton2.OverrideFocus.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton2.OverrideFocus.Border.Rounding = 10;
            this.kryptonButton2.OverrideFocus.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.OverrideFocus.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.Size = new System.Drawing.Size(295, 69);
            this.kryptonButton2.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton2.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonButton2.StateCommon.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton2.StateCommon.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton2.StateNormal.Border.Rounding = 10;
            this.kryptonButton2.StateNormal.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton2.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton2.StatePressed.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton2.StatePressed.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton2.TabIndex = 10;
            this.kryptonButton2.Values.Text = "Creadet Card";
            this.kryptonButton2.Click += new System.EventHandler(this.kryptonButton2_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(9, 293);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(117, 28);
            this.label25.TabIndex = 11;
            this.label25.Text = "Totoal Fee";
            // 
            // label_total_cost
            // 
            this.label_total_cost.AutoSize = true;
            this.label_total_cost.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_total_cost.Location = new System.Drawing.Point(140, 293);
            this.label_total_cost.Name = "label_total_cost";
            this.label_total_cost.Size = new System.Drawing.Size(64, 28);
            this.label_total_cost.TabIndex = 12;
            this.label_total_cost.Text = "188$";
            // 
            // kryptonButton3
            // 
            this.kryptonButton3.Cursor = System.Windows.Forms.Cursors.PanWest;
            this.kryptonButton3.Location = new System.Drawing.Point(1069, 281);
            this.kryptonButton3.Name = "kryptonButton3";
            this.kryptonButton3.OverrideDefault.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton3.OverrideDefault.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton3.OverrideDefault.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton3.OverrideDefault.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton3.OverrideDefault.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.OverrideDefault.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.OverrideFocus.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton3.OverrideFocus.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton3.OverrideFocus.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton3.OverrideFocus.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton3.OverrideFocus.Border.Rounding = 10;
            this.kryptonButton3.OverrideFocus.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.OverrideFocus.Content.ShortText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.Size = new System.Drawing.Size(78, 69);
            this.kryptonButton3.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton3.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.kryptonButton3.StateCommon.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Rounded;
            this.kryptonButton3.StateCommon.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonButton3.StateNormal.Border.Rounding = 10;
            this.kryptonButton3.StateNormal.Content.LongText.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(41)))));
            this.kryptonButton3.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(210)))));
            this.kryptonButton3.StatePressed.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.kryptonButton3.StatePressed.Content.LongText.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonButton3.TabIndex = 13;
            this.kryptonButton3.Values.Text = "Cancel";
            this.kryptonButton3.Click += new System.EventHandler(this.kryptonButton3_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form_book_rom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1179, 785);
            this.Controls.Add(this.kryptonButton3);
            this.Controls.Add(this.label_total_cost);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.kryptonButton2);
            this.Controls.Add(this.kryptonButton1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_book_rom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StateActive.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(169)))));
            this.StateActive.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(191)))), ((int)(((byte)(120)))));
            this.StateActive.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Switch50;
            this.StateActive.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.StateActive.Header.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(169)))));
            this.StateActive.Header.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(233)))), ((int)(((byte)(246)))));
            this.StateActive.Header.Back.ColorStyle = ComponentFactory.Krypton.Toolkit.PaletteColorStyle.Linear;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_book_rom_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_passport)).EndInit();
            this.kryptonPanel_passport.ResumeLayout(false);
            this.kryptonPanel_passport.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel7)).EndInit();
            this.kryptonPanel7.ResumeLayout(false);
            this.kryptonPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel4)).EndInit();
            this.kryptonPanel4.ResumeLayout(false);
            this.kryptonPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel2)).EndInit();
            this.kryptonPanel2.ResumeLayout(false);
            this.kryptonPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel3)).EndInit();
            this.kryptonPanel3.ResumeLayout(false);
            this.kryptonPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel8)).EndInit();
            this.kryptonPanel8.ResumeLayout(false);
            this.kryptonPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel_passport;
        private System.Windows.Forms.Label label1;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox_nationalty;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox_pasport_number;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox_name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radioButton_femal;
        private System.Windows.Forms.RadioButton radioButton_mal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_end_passport;
        private System.Windows.Forms.DateTimePicker dateTimePicker_birthdate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel7;
        private System.Windows.Forms.Label label_parking_vip;
        private System.Windows.Forms.Label label_parking_normal;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel4;
        private System.Windows.Forms.Label label_parking_cost_3;
        private System.Windows.Forms.Label label_parking_type_3;
        private System.Windows.Forms.Label label_parking_number_3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button4;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel2;
        private System.Windows.Forms.Label label_parking_cost_1;
        private System.Windows.Forms.Label label_parking_type_1;
        private System.Windows.Forms.Label label_parking_number_1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button3;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel3;
        private System.Windows.Forms.Label label_parking_cost_2;
        private System.Windows.Forms.Label label_parking_type_2;
        private System.Windows.Forms.Label label1_parking_number_2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button2;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel8;
        private System.Windows.Forms.Label label_parking_cost_4;
        private System.Windows.Forms.Label label_parking_type_4;
        private System.Windows.Forms.Label label_parking_number_4;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button button1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label_total_cost;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox_many_day_book_room;
        private System.Windows.Forms.Label label27;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox_many_day_book_parking;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label_total_cost_parking;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButton3;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}