﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using hotel_project;

namespace hotel_project
{
    public partial class Form_book_rom : KryptonForm
    {
        information_data_hotel.room_tabel.information_room info_room;
        information_data_hotel.parking_tabel.information_parking info_parking_after_click_button;
        information_data_hotel.customar_tabel.info_customar information_customar;

        information_data_hotel.parking_tabel.information_parking[] info_parking = new information_data_hotel.parking_tabel.information_parking[4];

        int cost = 0;

        public Form_book_rom(information_data_hotel.room_tabel.information_room info_room)
        {
            InitializeComponent();
            this.info_room = info_room;
            total_cost();
            format_parking();
        }

        void total_cost()
        {
            int cost_total_room = info_room.cost_room * Convert.ToInt32(kryptonTextBox_many_day_book_room.Text);
            cost_total_room += Convert.ToInt32(label_total_cost_parking.Text); 
            label_total_cost.Text = cost_total_room.ToString();

        }

        void full_information_customar()
        {
            information_customar.name = kryptonTextBox_name.Text;
            information_customar.birthdate = dateTimePicker_birthdate.Value;
            information_customar.nationalty = kryptonTextBox_nationalty.Text;
            information_customar.end_pasport = dateTimePicker_end_passport.Value;
            information_customar.pasport_number = Convert.ToInt32 (kryptonTextBox_pasport_number.Text);
            information_customar.gender = radioButton_mal.Checked;


        }

        private void Form_book_rom_FormClosed(object sender, FormClosedEventArgs e)
        {
            bool flage = false;
            foreach (Form form_open in Application.OpenForms)
            {
                if (!form_open.IsDisposed)
                    flage = true;
            }
            if (!flage)
                Application.Exit();
        }

        void open_form()
        {
            if (kryptonTextBox_name.Text.Length > 0
                && kryptonTextBox_nationalty.Text.Length > 0
                && kryptonTextBox_nationalty.Text.Length > 0)
            {
                information_customar.id = information_data_hotel.customar_tabel.add_customar(kryptonTextBox_name.Text, Convert.ToDateTime(dateTimePicker_birthdate.Text), kryptonTextBox_nationalty.Text
                     , radioButton_femal.Checked ? false : true, Convert.ToInt32(kryptonTextBox_pasport_number.Text), Convert.ToDateTime(dateTimePicker_end_passport.Text));
                if (information_customar.id > 0)
                {
                    
                    full_information_customar();
                    Form_issuing_invoice form = new Form_issuing_invoice(info_room ,information_customar ,info_parking_after_click_button ,
                        kryptonTextBox_many_day_book_room.Text ,((Convert.ToInt32(label_total_cost.Text))+(Convert.ToInt32(label_total_cost_parking.Text))).ToString() , kryptonTextBox_many_day_book_parking.Text);
                    form.Show();
                    this.Close();
                    return;
                }
            }
            MessageBox.Show("One OF This Input IS Wrong...", "Error", MessageBoxButtons.OK);
        }
        
        void format_parking()
        {
            information_data_hotel.parking_tabel.select_free_up_parking("normal parking", info_parking, 0);
            information_data_hotel.parking_tabel.select_free_up_parking("vip parking", info_parking, 2);

            if (info_parking[0].id_parking != 0)
            {
                label_parking_number_1.Text = info_parking[0].id_parking.ToString();
                label_parking_type_1.Text = info_parking[0].type_parking.ToString();
                label_parking_cost_1.Text = info_parking[0].cost_parking.ToString() + "$";
            }
            else
            {
                button3.Enabled = false;
            }


            if (info_parking[1].id_parking != 0)
            {
                label1_parking_number_2.Text = info_parking[1].id_parking.ToString();
                label_parking_type_2.Text = info_parking[1].type_parking.ToString();
                label_parking_cost_2.Text = info_parking[1].cost_parking.ToString() + "$";
            }
            else
            {
                button2.Enabled = false;
            }

           

            if (info_parking[2].id_parking != 0)
            {
                label_parking_number_3.Text = info_parking[2].id_parking.ToString();
                label_parking_type_3.Text = info_parking[2].type_parking.ToString();
                label_parking_cost_3.Text = info_parking[2].cost_parking.ToString() + "$";
            }
            else
            {
                button4.Enabled = false;
            }
            
            if (info_parking[3].id_parking != 0)
            {
                label_parking_number_4.Text = info_parking[3].id_parking.ToString();
                label_parking_type_4.Text = info_parking[3].type_parking.ToString();
                label_parking_cost_4.Text = info_parking[3].cost_parking.ToString() + "$";
            }
            else
            {
                button1.Enabled = false;
            }
            
        }

        void press_button_parking(information_data_hotel.parking_tabel.information_parking info_parking_after_click_button)
        {
            this.cost = info_parking_after_click_button.cost_parking;
            label_total_cost_parking.Text = cost.ToString();
            this.info_parking_after_click_button = info_parking_after_click_button;

        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
            open_form();
        }

        private void kryptonButton2_Click(object sender, EventArgs e)
        {
            open_form();
        }

        private void kryptonButton3_Click(object sender, EventArgs e)
        {
            Form_Select_room form = new Form_Select_room();
            form.Show();
            this.Close();
        }

        private void kryptonTextBox_many_day_book_room_TextChanged(object sender, EventArgs e)
        {
              if (kryptonTextBox_many_day_book_room.Text.Length > 0)
                total_cost();
        }

        private void kryptonTextBox_many_day_book_parking_TextChanged(object sender, EventArgs e)
        {
            if (kryptonTextBox_many_day_book_parking.Text.Length > 0 && kryptonTextBox_many_day_book_parking.Text != "0")
            {
                label_total_cost_parking.Text = (cost *
                   Convert.ToInt32(kryptonTextBox_many_day_book_parking.Text)).ToString() ;
            }
        }

        private void kryptonTextBox_many_day_book_room_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void kryptonTextBox_many_day_book_parking_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            press_button_parking(info_parking[0]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            press_button_parking(info_parking[1]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            press_button_parking(info_parking[2]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            press_button_parking(info_parking[3]);
        }

        private void kryptonTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;

        }

        private void radioButton_mal_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}




