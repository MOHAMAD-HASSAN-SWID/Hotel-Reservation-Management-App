﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace hotel_project
{
    public partial class Form_issuing_invoice : KryptonForm
    {
        /// <summary>
        /// false which mean reservation 
        /// true which mean cancel reservation
        /// </summary>
        bool reservation_or_cancel = false;
        information_data_hotel.room_tabel.information_room info_room;
        information_data_hotel.customar_tabel.info_customar info_Customar;
        information_data_hotel.parking_tabel.information_parking info_parking;
        string number_of_date_reservation;
        string number_of_date_reservation_parking;
        string reservation_cost;
        public Form_issuing_invoice(information_data_hotel.room_tabel.information_room info_room, 
            information_data_hotel.customar_tabel.info_customar info_Customar,
            information_data_hotel.parking_tabel.information_parking info_parking,
            string number_of_date_reservation,
            string reservation_cost,
            string number_of_date_reservation_parking)
        {
            InitializeComponent();
            this.info_room = info_room;
            format_room_number();
            this.info_Customar = info_Customar;
            this.info_parking = info_parking;
            this.number_of_date_reservation = number_of_date_reservation;
            this.reservation_cost = reservation_cost;
            this.number_of_date_reservation_parking = number_of_date_reservation_parking;
            full_information_room_customar();
            
        }

        void format_room_number()
        {
                comboBox_room_number.Enabled = false;
        }

        void full_information_room_customar()
        {
            comboBox_room_number.Text = info_room.id_room.ToString();
            label_name_customar.Text = info_Customar.name;
            label_pasport_number.Text = info_Customar.pasport_number.ToString();
            label_room_type.Text = info_room.type_room;
            label_parking_number.Text = info_parking.id_parking.ToString();
            label_parking_type.Text = info_parking.type_parking;
            label_end_date_reservation.Text = (dateTimePicker_date_reservation.Value.AddDays(Convert.ToDouble(number_of_date_reservation))).ToString();
            label_reservation_parking_end_date.Text = (dateTimePicker_reservation_parking_date.Value.AddDays(Convert.ToDouble(number_of_date_reservation_parking))).ToString();
            label_reservation_cost.Text = reservation_cost;
            int total_cost = (label_extra_service.Text == "Null" ? 0 : Convert.ToInt32(label_extra_service.Text)) +
                Convert.ToInt32(label_reservation_cost.Text);
            label_total_cost.Text = total_cost.ToString();
            label_by_user.Text = Form_signup.info_employee.name_employee;


        }

        private void Form_issuing_invoice_Load(object sender, EventArgs e)
        {

        }

        private void Form_issuing_invoice_FormClosed(object sender, FormClosedEventArgs e)
        {
            bool flage = false;
            foreach (Form form_open in Application.OpenForms)
            {
                if (!form_open.IsDisposed)
                    flage = true;
            }
            if (!flage)
                Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!reservation_or_cancel)
            {
                if (information_data_hotel.reservation_tabel.add_reservation(info_Customar.id, info_room.id_room, info_parking.id_parking,
                dateTimePicker_date_reservation.Value, Convert.ToDateTime(label_end_date_reservation.Text),
                Convert.ToInt32(reservation_cost), 0, dateTimePicker_reservation_parking_date.Value, Convert.ToDateTime(label_reservation_parking_end_date.Text)))
                {
                    MessageBox.Show("Reservation Successfully", "Successfully", MessageBoxButtons.OK);
                    Form_Select_room form = new Form_Select_room();
                    form.Show();
                    this.Close();
                }
            }

            else
            {
                if (MessageBox.Show("Are you sure about cancelling the reservation?"  , "warnning",MessageBoxButtons.OKCancel)== DialogResult.OK)
                {
                    int value1 = Convert.ToInt32(reservation_bill.Rows[0]["reservation_id"]);
                    int value2 = Convert.ToInt32(reservation_bill.Rows[0]["room_id"]);
                    int value3 = Convert.ToInt32(reservation_bill.Rows[0]["parking_id"]);
                    information_data_hotel.reservation_tabel.end_reservation(value1, value2, value3);
                    Form_Select_room form = new Form_Select_room();
                    form.Show();
                    this.Close();
                }
            }
            
        }

        private void dateTimePicker_date_reservation_ValueChanged(object sender, EventArgs e)
        {
            label_end_date_reservation.Text = (dateTimePicker_date_reservation.Value.AddDays(Convert.ToDouble(number_of_date_reservation))).ToString();
        }


        // this section to end reservation .....

        DataTable reservation_bill = new DataTable();

        public Form_issuing_invoice()
        {
            InitializeComponent();
            reservation_or_cancel = true;
            get_all_reservation_room();
        }

        void get_all_reservation_room()
        {
            button_serch_button.Visible = true;
            button1.Enabled = false;
            DataTable reservation_room = information_data_hotel.room_tabel.select_reservation_room();
            if (reservation_room!=null)
                foreach (DataRow row in reservation_room.Rows)
                    comboBox_room_number.Items.Add(row[0].ToString());
        }

        void full_information_room_customar_to_end_reservation()
        {
            label_name_customar.Text = reservation_bill.Rows[0]["customar_name"].ToString();
            label_pasport_number.Text = reservation_bill.Rows[0]["passport_number"].ToString();
            label_room_type.Text = reservation_bill.Rows[0]["service_name"].ToString();
            label_parking_number.Text = reservation_bill.Rows[0]["parking_id"].ToString();
            label_parking_type.Text = reservation_bill.Rows[0]["parking_service_name"].ToString();
            dateTimePicker_date_reservation.Text = reservation_bill.Rows[0]["reservation_date"].ToString();
            dateTimePicker_date_reservation.Enabled = false;
            label_end_date_reservation.Text = reservation_bill.Rows[0]["reservation_end_date"].ToString();
            dateTimePicker_reservation_parking_date.Text = reservation_bill.Rows[0]["reservation_parking_date"].ToString();
            dateTimePicker_reservation_parking_date.Enabled = false;
            label_reservation_parking_end_date.Text = reservation_bill.Rows[0]["reservation_parkink_end_date"].ToString();
            label_reservation_cost.Text = reservation_bill.Rows[0]["reservation_coast"].ToString();
            label_total_cost.Text = reservation_bill.Rows[0]["service_total_coast"].ToString();
            label_by_user.Text = Form_signup.info_employee.name_employee;
        }

        private void button_serch_button_Click(object sender, EventArgs e)
        {
             reservation_bill = information_data_hotel.reservation_tabel.get_reservation_not_end(Convert.ToInt32(comboBox_room_number.Text));
            if (reservation_bill != null)
            { 
                full_information_room_customar_to_end_reservation();
                button1.Enabled = true;
            }
            else
                MessageBox.Show("This Room Not Reservation Cheack Agin", "Warnning", MessageBoxButtons.OK);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form_Select_room form = new Form_Select_room();
            form.Show();
            this.Close();
        }

        private void comboBox_room_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }
    }
}
