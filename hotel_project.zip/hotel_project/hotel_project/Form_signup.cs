﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace hotel_project
{
    public partial class Form_signup : KryptonForm
    {
        public Form_signup()
        {
            InitializeComponent();
        }

        public static information_data_hotel.role_employee_tabel.info_role_employye info_employee = 
            new information_data_hotel.role_employee_tabel.info_role_employye();

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
            if (information_data_hotel.role_employee_tabel.is_find_employee
                (kryptonMaskedTextBox_name_employee.Text, kryptonMaskedTextBox_id_employee.Text))
            {
                info_employee = information_data_hotel.role_employee_tabel.get_info_employee();
                Form_Select_room form = new Form_Select_room();
                form.Show();
                this.Close();
            }
            else if (kryptonMaskedTextBox_id_employee.Text.Length <= 0)
                errorProvider1.SetError(kryptonMaskedTextBox_id_employee, "Empty value");
            else
            {
                MessageBox.Show("This Employee Not Found","Error",MessageBoxButtons.OK);
            }
        }

        private void Form_signup_FormClosed(object sender, FormClosedEventArgs e)
        {
            bool flage = false;
            foreach (Form form_open in Application.OpenForms)
            {
                if (!form_open.IsDisposed)
                {
                    flage = true;
                    break;
                }
            }
            if (!flage)
                Application.Exit();
        }
    }
}

