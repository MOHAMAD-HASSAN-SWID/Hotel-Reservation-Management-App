﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace information_data_hotel
{
    public class role_employee_tabel
    {
        public struct info_role_employye
        {
            public int id_role;
            public string name_type_role;
            public int id_employee;
            public string name_employee;
        }

        static int _id_employee = 0;

        public static bool is_find_employee(string name_employee, string id_employee)
        {
            bool is_found = false;
            _id_employee = connection_data_hotel.employyees_and_role_tabel.find_employee(name_employee, id_employee);
            if (_id_employee != 0)
            {
                is_found = true;
            }
            else
                is_found = false;
            return is_found;
        }

        public static info_role_employye get_info_employee()
        {
            info_role_employye info_employee = new info_role_employye();
            if (_id_employee == 0)
                return info_employee;
            DataTable data_employee = connection_data_hotel.employyees_and_role_tabel.get_employee(_id_employee);
            info_employee.id_role = Convert.ToInt32(data_employee.Rows[0]["role_id"]);
            info_employee.name_type_role = data_employee.Rows[0]["role_type_name"].ToString();
            info_employee.id_employee = Convert.ToInt32(data_employee.Rows[0]["employee_id"]);
            info_employee.name_employee = data_employee.Rows[0]["employee_name"].ToString();
            return info_employee;
        }

    }

    public class room_tabel
    {
        public struct information_room
        {
            public int id_room;
            public string type_room;
            public int cost_room;
        }

        public static void select_free_up_room(string room_type, information_room[] convert_info_room, int top_number)
        {
            DataTable data_room = connection_data_hotel.room_tabel.select_free_room(room_type);
            if (data_room != null)
            {
                for (int i = 0; i < 2; i++)
                {
                    try
                    {
                        convert_info_room[i + top_number].id_room = Convert.ToInt32(data_room.Rows[i]["room_id"]);
                        convert_info_room[i + top_number].type_room = data_room.Rows[i]["service_name"].ToString();
                        convert_info_room[i + top_number].cost_room = Convert.ToInt32(data_room.Rows[i]["coast"]);
                    }
                    catch 
                    {
                        convert_info_room[i + top_number].id_room   =  0;
                        convert_info_room[i + top_number].type_room =  null;
                        convert_info_room[i + top_number].cost_room =  0;

                    }
                }
            }
        }

        public static int count_free_room(int tariffs_id)
        {
            return connection_data_hotel.room_tabel.count_rows_free(tariffs_id);
        }

        public static DataTable select_reservation_room()
        {
            return connection_data_hotel.room_tabel.select_reservation_room();
        }

    }

    public class parking_tabel
    {
        public struct information_parking
        {
            public int id_parking;
            public string type_parking;
            public int cost_parking;
        }

        public static void select_free_up_parking(string room_type, information_parking[] convert_info_room, int top_number)
        {
            DataTable data_room = connection_data_hotel.parking_tabel.select_free_parking(room_type);
            if (data_room != null)
            {
                for (int i = 0; i < 2; i++)
                {
                    try
                    {
                        convert_info_room[i + top_number].id_parking = Convert.ToInt32(data_room.Rows[i]["parking_id"]);
                        convert_info_room[i + top_number].type_parking = data_room.Rows[i]["service_name"].ToString();
                        convert_info_room[i + top_number].cost_parking = Convert.ToInt32(data_room.Rows[i]["coast"]);
                    }
                    catch
                    {
                        convert_info_room[i + top_number].id_parking = 0;
                        convert_info_room[i + top_number].type_parking = null;
                        convert_info_room[i + top_number].cost_parking = 0;
                    }
                    
                }
            }
        }

        public static int count_free_parking(int tariffs_id)
        {
            return connection_data_hotel.parking_tabel.count_parking_free(tariffs_id);
        }

    }

    public class customar_tabel
    {
        public struct info_customar
        {
            public int id;
            public string name;
            public DateTime birthdate;
            public string nationalty;
            public bool gender;
            public int pasport_number;
            public DateTime end_pasport;
        }
        public static int add_customar(string name, DateTime birthdate, string nationalaty, bool gendar
            , int pasport_number, DateTime end_pasport)
        {

            return connection_data_hotel.customar_tabel.add_customar(name, birthdate, nationalaty, gendar, pasport_number, end_pasport);
        }
    }

    public class reservation_tabel
    {
        public struct informaation_reservation
        {
            public int reservation_id;
            public int customar_id;
            public int room_id;
            public int parking_id;
            public DateTime reservation_date;
            public DateTime reservation_end_date;
            public int reservation_cost;
            public int service_total_cost;
        }

        public static bool add_reservation(int customar_id,
                 int room_id ,int parking_id, DateTime reservation_date ,
                DateTime reservation_end_date , int reservation_cost ,int service_total_cost
            ,DateTime reservation_parking_date, DateTime reservation_parkink_end_date
                )
        {
            return connection_data_hotel.reservation_tabel.add_reservation(customar_id,
                 room_id , parking_id, reservation_date , 
                reservation_end_date , reservation_cost , service_total_cost 
                ,  reservation_parking_date,  reservation_parkink_end_date
                );

        }

        public static DataTable get_reservation_not_end(int room_id)
        {
            return connection_data_hotel.reservation_tabel.get_reservation_not_end(room_id);
        }

        public static bool end_reservation(int reservation_id, int room_id, int parking_id)
        {
            return connection_data_hotel.reservation_tabel.end_reservation(reservation_id, room_id, parking_id);
        }
    }
}
